const SEO = {
  title: "Uniedge Company Limited - Zanzibar Consulting Experts",
  description: "Uniedge Company Limited is Zanzibar's trusted partner for business strategy, tax consulting, marketing services, and B2B agency supply. Driven by Insights, Powered by Results.",
  author: "Uniedge Company Limited",
};
export default SEO;
